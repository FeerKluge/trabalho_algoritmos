import csv

def abrir_arquivo(): #essa função vai abrir o arquivo, e retornar caso digite errado.
    caminho = input("DIGITE O CAMINHO DO ARQUIVO: ")
    print("--------------------------------------------------------------")
    print("O CAMINHO ADICIONADO ESTÁ CORRETO? ")
    print("[1]SIM")
    print("[2]NÃO, QUERO ALTERAR.")
    print("--------------------------------------------------------------")
    escolha_caminho = input("DIGITE A OPÇÃO: ")
    if escolha_caminho == "2":
        return abrir_arquivo()
    else:
       return interface(caminho)
    
def interface(caminho): #função da interface, que direciona para as funções necessárias.
    print("--------------------------------------------------------------")
    print("[1]VERIFICAR RELATÓRIO DO ARQUIVO")
    print("[2]PESQUISAR CANDIDATOS")
    print("[3]PESQUISAR RELAÇÃO PARTIDO x CIDADES")
    print("[4]PESQUISAR CANDIDATO MAIS VOTADO DO PRIMEIRO TURNO")
    print("--------------------------------------------------------------")

    opcao_interface = input("DIGITE A OPÇÃO QUE VOCÊ DESEJA: ")
    opcao_interface = str(opcao_interface)

    print("--------------------------------------------------------------")
    if opcao_interface != "1" and opcao_interface != "2" and opcao_interface != "3" and opcao_interface != "4":
        
        return interface()
    # aqui é feita a verificação de qual função é necessária.
    if opcao_interface == "1": 
        relatorio(caminho, opcao_interface)
    if opcao_interface == "2":
        pesquisar_candidatos(caminho, opcao_interface)
    if opcao_interface == "3":
        partidoXcidade(caminho)
    if opcao_interface == "4":
        mais_votado(caminho, opcao_interface)
    else:
        print("OPÇÃO INVÁLIDA, DIGITE NOVAMENTE")
        return interface()
    
def selecionar_cargo(): #essa função é responsável por atribuir o cargo solicitado.
    print("--------------------------------------------------------------")
    print("[1]Prefeito")
    print("[2]Vereador")
    print("[3]Todos")
    print("--------------------------------------------------------------")
    cargo_selecionado = input("DIGITE O CARGO QUE DESEJA FILTRAR: ")
    cargo_selecionado = str(cargo_selecionado)
    if cargo_selecionado == "1":
        return "PREFEITO"
    elif cargo_selecionado == "2":
        return "VEREADOR"
    elif cargo_selecionado == "3":
        return "TODOS"
    else: 
        print("OPÇÃO INVÁLIDA, DIGITE NOVAMENTE")

        return selecionar_cargo()
    
def relatorio(caminho, opcao_interface): #essa função vai mostrar o número de linhas e o cabeçalho do arquivo.    
    with open(caminho, "r") as arquivo:
        linha = arquivo.readlines()
        n_linha = len(linha)

    with open(caminho, mode="r") as arquivo:    
        leitor_csv = csv.reader(arquivo, delimiter=";")
        cabecalho = next(leitor_csv)
            
        print(f"O ARQUIVO POSSUI {n_linha} LINHAS")
        print("--------------------------------------------------------------")
        print(f"COLUNAS ENCONTRADAS: {cabecalho}")
        print("--------------------------------------------------------------")

    resetar(caminho)    

def mais_votado(caminho, opcao_interface): #essa função busca o candidato mais votado da cidade solicitada.
    cidade = input("DIGITE A CIDADE: ")
    cidade = cidade.strip().upper()

    with open(caminho, mode="r") as arquivo:
        leitor_csv = csv.reader(arquivo, delimiter=";")
        cabecalho = next(leitor_csv)
    
        municipio_id = cabecalho.index("NM_MUNICIPIO")
        candidato_id = cabecalho.index("NM_VOTAVEL")
        qt_votos_id = cabecalho.index("QT_VOTOS")
        cd_candidato_id = cabecalho.index("CD_CARGO_PERGUNTA")
        sg_partido_id = cabecalho.index("SG_PARTIDO")
        nm_partido_id = cabecalho.index("NR_PARTIDO")

        cargo_selecionado = selecionar_cargo()

        if cargo_selecionado == "TODOS":
            print(f"BUSCANDO TODAS AS INFORMAÇÕES SOBRE {cidade}...")
        else:
            print(f"BUSCANDO INFORMAÇÕES SOBRE O CARGO DE {cargo_selecionado} EM {cidade}...")
            
        votos_candidatos = {} #objeto que vai armazenar as informações dos candidatos.
    
        for linha in leitor_csv:
            municipio = linha[municipio_id]  # Aqui vai buscar o nome da cidade no arquivo.
            candidato = linha[candidato_id]  # Aqui vai buscar o nome do candidato no arquivo.
            qt_votos = linha[qt_votos_id]    # Aqui vai buscar a quantidade de votos no arquivo.
            cd_candidato = linha[cd_candidato_id] #Aqui vai buscar o código do candidato no arquivo.
            sg_candidato = linha[sg_partido_id] # Aqui vai buscar a sigla do partido no arquivo.

            #aqui é feita a verificação do cargo a partir do código do arquivo
            if cd_candidato == "11":
                cargo = "PREFEITO"
            elif cd_candidato == "13":
                cargo = "VEREADOR"
            else:
                cargo = "OUTRO"    
                
            if cargo_selecionado != "TODOS" and cargo != cargo_selecionado:
                continue 
            
            #aqui verifica se é voto branco ou nulo, se for, pula a linha do arquivo.
            if candidato in ["Branco", "Nulo"]:
                continue

            if municipio == cidade:
                if qt_votos.isdigit():
                    qt_votos = int(qt_votos)
                else:
                    continue

                if candidato not in votos_candidatos:
                    votos_candidatos[candidato] = {"votos": 0, "cargo": cargo, "partido": sg_candidato}

                votos_candidatos[candidato]["votos"] += qt_votos

        #aqui vai verificar quem fez mais votos, colocar em ordem e printar o mais votado.
        if opcao_interface == "4":
            vencedor = sorted(votos_candidatos.items(), key=lambda item: item[1]["votos"], reverse=True)
            vencedor = vencedor[:1]
            print(vencedor)        
    resetar(caminho)           

def pesquisar_candidatos(caminho, opcao_interface): #essa função funciona da mesma forma da anterior, porém no final ela printa todos os candidatos da cidade.
    cidade = input("DIGITE A CIDADE: ")
    cidade = cidade.strip().upper()

    with open(caminho, mode="r") as arquivo:
        leitor_csv = csv.reader(arquivo, delimiter=";")
        cabecalho = next(leitor_csv) 
    
        municipio_id = cabecalho.index("NM_MUNICIPIO")
        candidato_id = cabecalho.index("NM_VOTAVEL")
        qt_votos_id = cabecalho.index("QT_VOTOS")
        cd_candidato_id = cabecalho.index("CD_CARGO_PERGUNTA")
        sg_partido_id = cabecalho.index("SG_PARTIDO")
        nm_partido_id = cabecalho.index("NR_PARTIDO")

        cargo_selecionado = selecionar_cargo()
        
        print("--------------------------------------------------------------")
        print("GERAR NOVO ARQUIVO DE RELATÓRIO?")
        print("[1]SIM")
        print("[2]NÃO")
        opcao = int(input("DIGITE A SUA OPÇÃO: "))
        opcao = str(opcao) 
        print("--------------------------------------------------------------")    

        if cargo_selecionado == "TODOS":
            print(f"BUSCANDO TODAS AS INFORMAÇÕES SOBRE {cidade}...")
        else:
            print(f"BUSCANDO INFORMAÇÕES SOBRE O CARGO DE {cargo_selecionado} EM {cidade}...")
            
        votos_candidatos = {}
    
        for linha in leitor_csv:
            municipio = linha[municipio_id]  
            candidato = linha[candidato_id]  
            qt_votos = linha[qt_votos_id]    
            cd_candidato = linha[cd_candidato_id] 
            sg_candidato = linha[sg_partido_id] 

            if cd_candidato == "11":
                cargo = "PREFEITO"
            elif cd_candidato == "13":
                cargo = "VEREADOR"
            else:
                cargo = "OUTRO"    
                
            if cargo_selecionado != "TODOS" and cargo != cargo_selecionado:
                continue 

            if candidato in ["Branco", "Nulo"]:
                continue

            if municipio == cidade:
                if qt_votos.isdigit():
                    qt_votos = int(qt_votos)
                else:
                    continue

                if candidato not in votos_candidatos:
                    votos_candidatos[candidato] = {"votos": 0, "cargo": cargo, "partido": sg_candidato}

                votos_candidatos[candidato]["votos"] += qt_votos
        
        #se o usuário requisitar, aqui vai gerar um novo arquivo com as informações fitradas (precisa colocar .csv no final).
        if opcao == "1":
            nome_arquivo = input("DIGITE O NOME DO NOVO ARQUIVO: ")
            cabecalho = ["Candidato", "Votos", "Cargo", "Partido"]
    
            with open(nome_arquivo, mode="w", newline="") as arquivo_csv:
                escritor = csv.writer(arquivo_csv)       
                escritor.writerow(cabecalho)
                
                for candidato, detalhes in votos_candidatos.items():
                    linha = [candidato, detalhes["votos"], detalhes["cargo"], detalhes["partido"]]
                    escritor.writerow(linha)
            
            print("SEU ARQUIVO FOI CRIADO.")
        #caso o usuário não queira um novo arquivo, vai printar no terminal.       
        else:
            for candidato, votos in votos_candidatos.items():
                print(f"Candidato: {candidato}, Votos: {votos}")
     
    resetar(caminho)            

def partidoXcidade(caminho): #essa função vai unir os votos dos partidos nas cidades, para que fique mais fácil a visualização.
    with open(caminho, mode="r") as arquivo:
        leitor_csv = csv.reader(arquivo, delimiter=";")
        cabecalho = next(leitor_csv)

        municipio_id = cabecalho.index("NM_MUNICIPIO")
        partido_id = cabecalho.index("SG_PARTIDO")
        qt_votos_id = cabecalho.index("QT_VOTOS")

        votos_por_cidade = {}

        for linha in leitor_csv:
            municipio = linha[municipio_id].strip().upper()
            partido = linha[partido_id].strip().upper()
            qt_votos = linha[qt_votos_id]

            if not qt_votos.isdigit(): #verifica se a linha do arquivo é um digito, se não for, pula a linha.
                continue
            
            qt_votos = int(qt_votos)

            if municipio not in votos_por_cidade:
                votos_por_cidade[municipio] = {}

            if partido not in votos_por_cidade[municipio]:
                votos_por_cidade[municipio][partido] = 0
            
            votos_por_cidade[municipio][partido] += qt_votos
    
    #aqui o novo arquivo não é opcional, portanto o usuário vai digitar o nome do novo arquivo (precisa colocar .csv no final).
    nome_arquivo = input("DIGITE O NOME DO ARQUIVO: ")
    cabecalho = ["Cidade", "Partido", "Votos"]
    
    with open(nome_arquivo, mode="w", newline="") as arquivo_csv:
        escritor = csv.writer(arquivo_csv)       
        escritor.writerow(cabecalho)
                
        for cidade, partido in votos_por_cidade.items():
            for partido, votos in partido.items():
                escritor.writerow([cidade, partido, votos])  
    resetar(caminho)

def resetar(caminho): #essa função vai aparecer no final de todas a outras, para que o usuário possa voltar para a interface ou sair.
    print("--------------------------------------------------------------")
    print("DESEJA RETORNAR A INTERFACE?")
    print("[1]SIM")
    print("[2]NÃO")
    escolha_resetar = int(input("DIGITE A SUA OPÇÃO: "))
    escolha_resetar = str(escolha_resetar)

    if escolha_resetar == "1":
        interface(caminho)
    else:
        print("ATÉ LOGO!")
        exit()    

abrir_arquivo() #o código todo funciona a partir dessa função.